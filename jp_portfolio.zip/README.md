<img src="https://miro.medium.com/max/1400/1*2xsLeLNqKwIoGOQlw8O6Ug.png" alt="html javaScript css"  width="100%" height="350">

## 言語

[![영어](https://img.shields.io/badge/Language-English-blueviolet?style=for-the-badge)](README%20eng.md)
[![일본어](https://img.shields.io/badge/Language-Japanese-blueviolet?style=for-the-badge)](README.md)
<br><br>

## 導入

<b>このリポジトリは HTML レクチャーに関するものです</b>

### pip install

-pip install django
-pip install pillow
-pip install django-allauth
-pip install django-baton
